#include <iostream>
#include "Animal.h"
#include "Animal_health.h"
#include "date.h"
#include <string.h>
using namespace std;

int main()
{
    int MAX_ANIMALS=100;
    int animal_count=0;
    int choice,age,day,month,year;
    char gender;
    string id,name,group,status,keeper,diet,category,supply,past_habitat,species,area,location;
    date given_date;
    Animal* animals[MAX_ANIMALS];
    //destroy_records[animals,MAX_ANIMALS];

  /*  Animal_health* animal1;
    Animal* animal11=new Animal_health("lim3_1","lion",2,3,'M',12,150.5,"Mammal","sick","Ali","Meat","Carnivore","Adequate Supply");
    dob.set_date(20,10,2004);
    Habitat* animal;
    animal=new Habitat("Africa","Common",dob,"Zone B","South",animal1);
    animal->sick_wrt_age(choice);*/
    //
    do {

        cout << "1. Add animal" << endl;
        cout << "2. Delete animal by ID" << endl;
        cout << "3. Find animal by ID" << endl;
        cout << "4. Find animals within a particular location" << endl;
        cout << "5. List of animals of category, keeper, and dietary conditions" << endl;
        cout << "6. Frequency of animals reported sick" << endl;
        cout << "7. Destroy all records for animals" << endl;
        cout << "8. Number of animals born between today and a given date" << endl;
        cout << "9. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            add_animal(animals,MAX_ANIMALS,animal_count);
            break;
        case 2:
            cout<<"Enter id to delete animal:";
            cin.ignore();
            getline(cin,id);
            delete_animal(animals,MAX_ANIMALS,id,animal_count);
            break;
        case 3:
            cout<<"Enter id to find:";
            cin.ignore();
            getline(cin,id);
            find_animal(animals,MAX_ANIMALS,id);
            break;
        case 4:
            cout<<"Enter location:";
            cin.ignore();
            getline(cin,location);
        for(int z=0;z<MAX_ANIMALS;z++){
            animals[z]->display_animal(location);
        }
        break;
        case 5:
        int ch;
    cout<<"Press 1 to display all animals of certain category."<<endl;
    cout<<"Press 2 to display all animals under certain caretaker."<<endl;
    cout<<"Press 3 to display all animals with certain diet."<<endl;
    cout<<"Press 4 to display animals with all of the above."<<endl;
    cout<<"Press any other number to exit."<<endl;
    do{
        cout << "Enter your choice: ";
        cin>>ch;
        switch(ch){
            case 1:
                cout<<"Enter category:";
                cin.ignore();
                getline(cin, category);
                for(int z=0;z<MAX_ANIMALS;z++){
                    animals[z]->categorised_display(category);
                }
            break;
            case 2:
                cout<<"Enter caretaker name:";
                cin.ignore();
                getline(cin, keeper);
                for(int z=0;z<MAX_ANIMALS;z++){
                    animals[z]->display_wrt_keeper(keeper);
                    }
            break;
            case 3:
                cout<<"Enter diet:";
                cin.ignore();
                getline(cin, diet);
                for(int z=0;z<MAX_ANIMALS;z++){
                    animals[z]->display_wrt_diet(diet);
                    }
            break;
            case 4:
                cout<<"Enter category:";
                cin.ignore();
                getline(cin, category);
                cout<<"Enter caretaker name:";
                cin.ignore();
                getline(cin, keeper);
                cout<<"Enter diet:";
                cin.ignore();
                getline(cin, diet);
                for(int z=0;z<MAX_ANIMALS;z++){
                    animals[z]->detailed_display(category,keeper,diet);
                    }
            break;
            default:
            break;
            }
        }while(ch>0&&ch<5);
        break;
    case 6:
        int cho;
        cout << "1. Display sick animals by category" << endl;
        cout << "2. Display sick animals by age" << endl;
        cout << "3. Display sick animals by gender" << endl;
        cout << "4. Display sick animals by location" << endl;
        cout << "5. Display sick animals by date range" << endl;
        cout << "6. Exit" << endl;
    do {
        cout << "Enter your choice: ";
        cin >> cho;
        switch (cho) {
            case 1:
        cout<<"Enter category:";
        cin.ignore();
        getline(cin, category);
        for(int z=0;z<MAX_ANIMALS;z++){
            animals[z]->sick_wrt_cat(category);
        }
            break;
            case 2:
                cout<<"Enter animal age:";
                cin>>age;
                for(int z=0;z<MAX_ANIMALS;z++){
                    animals[z]->sick_wrt_age(age);

                }
            break;
            case 3:
                cout<<"Enter animal gender(M,F):";
                cin>>gender;
                for(int z=0;z<MAX_ANIMALS;z++){
                    animals[z]->sick_wrt_gender(gender);

                }
            break;
            case 4:
                cout<<"Enter location:";
                cin.ignore();
                getline(cin,location);
                for(int z=0;z<MAX_ANIMALS;z++){
                animals[z]->sick_wrt_location(location);
                }
            break;
            case 5:
                cout<<"Enter day,month and year:";
                cin>>day>>month>>year;
                given_date.set_date(day,month,year);
                for(int z=0;z<MAX_ANIMALS;z++){
                    animals[z]->sick_wrt_date(given_date);
                }
            default:
            break;
            }
     }while(cho>0&&cho<6);
        break;
        case 7:
        cout<<"Number of sick animals are:"<<sick_frequency(animals,MAX_ANIMALS);
        break;
        case 8:
            cout<<"Enter day, month and year:";
            cin>>day>>month>>year;
            given_date.set_date(day,month,year);
            cout<<"Number of animals born between "<<day<<"-"<<month<<"-"<<year;
            cout<<" and today are:"<<born_between_dates(animals,MAX_ANIMALS,given_date)<<endl;
        break;
        case 9:
            destroy_records(animals,MAX_ANIMALS);

     } }while(choice>0&&choice<5);
    return 0;

}


